from io import BytesIO
from typing import Optional, Tuple

from PIL import Image


class InvalidImageError(Exception):
    """Raised when the input is not a valid image."""


class NotBrainMRIError(Exception):
    """Raised when the image is valid but clearly not a brain MRI."""


class BrainTumorClassifier:
    """
    Dummy classifier used only to get the Azure deployment working.

    - Validates that the uploaded file is an image.
    - Applies some simple heuristics to reject obvious non‑MRI images.
    - Always returns a fixed prediction for valid MRI‑like images.
    """

    def __init__(self, model_path: Optional[str] = None) -> None:
        self.model_path = model_path

    def _validate_image(self, image: Image.Image) -> None:
        """
        Raise:
          - InvalidImageError if image is invalid
          - NotBrainMRIError if it looks clearly not like a brain MRI
        """
        # Basic validity: mode and size
        if image.mode not in ("RGB", "L"):
            raise InvalidImageError("Unsupported image mode")

        width, height = image.size  # type: Tuple[int, int]

        # Reject extremely small images (e.g. icons, thumbnails)
        if width < 128 or height < 128:
            raise NotBrainMRIError("Image too small to be a brain MRI")

        # Brain MRI images are usually close to square
        aspect_ratio = max(width, height) / min(width, height)
        if aspect_ratio > 1.6:
            raise NotBrainMRIError(
                "Image does not look like a brain MRI (wrong aspect ratio)"
            )

    def predict_image_from_pil(self, image: Image.Image) -> dict:
        """
        Accepts a PIL image and returns a prediction dict
        or raises a validation error.
        """
        self._validate_image(image)

        # Dummy prediction for now
        return {
            "label": 0,
            "label_name": "no_tumor",
            "probability": 0.95,
        }

    def predict(self, image_bytes: bytes) -> str:
        """
        Alternate interface: accept raw bytes and return a string.
        """
        try:
            img = Image.open(BytesIO(image_bytes)).convert("RGB")
        except Exception:
            raise InvalidImageError("Could not open image")

        self._validate_image(img)
        return "No Tumor (dummy prediction)"